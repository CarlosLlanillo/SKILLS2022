<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('animales', function () {
    return view('Listado de animales');
});

Route::get('animales/{animal}', function ($animal) {
    return view('Vista en detalle del animal '.$animal);
})->where('animal','[A-Za-z]+');

Route::get('animales/crear', function () {
    return view('Añadir un animal');
});

Route::get('animales/{animal}/editar', function () {
    return view('Modificar un animal');
});